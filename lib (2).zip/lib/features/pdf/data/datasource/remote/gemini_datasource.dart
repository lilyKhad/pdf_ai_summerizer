import 'dart:convert';
import 'package:http/http.dart' as http;

abstract class GeminiDataSource {
  Future<String> summarizePdf(String fileUrl);
}

class GeminiDataSourceImpl implements GeminiDataSource {
  final String apiKey;
  static const _model = 'gemini-1.5-flash';
  static const _baseUrl =
      'https://generativelanguage.googleapis.com/v1beta/models';

  GeminiDataSourceImpl({required this.apiKey});

  @override
  Future<String> summarizePdf(String fileUrl) async {
    // Step 1: download the PDF bytes from Supabase
    final fileResponse = await http.get(Uri.parse(fileUrl));
    if (fileResponse.statusCode != 200) {
      throw Exception('Failed to download PDF from Supabase');
    }

    // Step 2: convert to base64
    final base64Pdf = base64Encode(fileResponse.bodyBytes);

    // Step 3: send to Gemini with base64 inline
    final uri = Uri.parse('$_baseUrl/$_model:generateContent?key=$apiKey');

    final body = jsonEncode({
      'contents': [
        {
          'parts': [
            {
              'text': '''You are a document summarizer.
Please provide a clear and concise summary of this PDF document.
Structure your response with:
- A brief overview (2-3 sentences)
- Key points (bullet points)
- Main conclusion'''
            },
            {
              'inline_data': {
                'mime_type': 'application/pdf',
                'data': base64Pdf,       // ← base64 string here
              }
            }
          ]
        }
      ],
      'generationConfig': {
        'temperature': 0.3,
        'maxOutputTokens': 1024,
      }
    });

    final geminiResponse = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: body,
    );

    if (geminiResponse.statusCode != 200) {
      throw Exception(
          'Gemini API error: ${geminiResponse.statusCode} — ${geminiResponse.body}');
    }

    // Step 4: extract the summary text
    final json = jsonDecode(geminiResponse.body) as Map<String, dynamic>;
    final candidates = json['candidates'] as List;

    if (candidates.isEmpty) {
      throw Exception('Gemini returned no candidates');
    }

    return candidates[0]['content']['parts'][0]['text'] as String;
  }
}