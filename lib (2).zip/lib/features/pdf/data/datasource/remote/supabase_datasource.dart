import 'dart:io';
import 'package:pdf_summerizer/features/pdf/data/model/document_module.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

abstract class DocumentRemoteDataSource {
  Future<DocumentModel> uploadDocument(String filePath);
  Future<List<DocumentModel>> getAllDocuments();
  Future<DocumentModel> getDocument(String documentId);
  Future<void> deleteDocument(String documentId);
  Future<DocumentModel> updateDocument(DocumentModel model);
}

class DocumentRemoteDataSourceImpl implements DocumentRemoteDataSource {
  final SupabaseClient supabase;
  static const _bucket = 'pdfs';
  static const _table = 'documents';

  DocumentRemoteDataSourceImpl({required this.supabase});

  String get _userId => supabase.auth.currentUser!.id;

  @override
  Future<DocumentModel> uploadDocument(String filePath) async {
    final file = File(filePath);
    final fileName = p.basename(filePath);
    final documentId = const Uuid().v4();

    // upload file to Supabase Storage: pdfs/{userId}/{fileName}
    final storagePath = '$_userId/$fileName';
    await supabase.storage.from(_bucket).upload(storagePath, file);

    // get public URL
    final url = supabase.storage.from(_bucket).getPublicUrl(storagePath);

    // get file size in MB
    final size = file.lengthSync() / (1024 * 1024);

    // insert row in documents table
    final response = await supabase.from(_table).insert({
      'id': documentId,
      'user_id': _userId,
      'name': fileName,
      'url': url,
      'size': size,
      'status': 'idle',
      'uploaded_at': DateTime.now().toIso8601String(),
    }).select().single();

    return DocumentModel.fromJson(response);
  }

  @override
  Future<List<DocumentModel>> getAllDocuments() async {
    final response = await supabase
        .from(_table)
        .select()
        .order('uploaded_at', ascending: false);

    return (response as List)
        .map((json) => DocumentModel.fromJson(json as Map<String, dynamic>))
        .toList();
  }

  @override
  Future<DocumentModel> getDocument(String documentId) async {
    final response = await supabase
        .from(_table)
        .select()
        .eq('id', documentId)
        .single();

    return DocumentModel.fromJson(response);
  }

  @override
  Future<void> deleteDocument(String documentId) async {
    // get doc first to find the storage path
    final doc = await getDocument(documentId);

    // extract storage path from URL: pdfs/{userId}/{fileName}
    final uri = Uri.parse(doc.url);
    final storagePath = uri.pathSegments
        .skipWhile((s) => s != _bucket)
        .skip(1)
        .join('/');

    // delete from storage
    await supabase.storage.from(_bucket).remove([storagePath]);

    // delete from DB
    await supabase.from(_table).delete().eq('id', documentId);
  }

  @override
  Future<DocumentModel> updateDocument(DocumentModel model) async {
    final response = await supabase
        .from(_table)
        .update({
          'status': model.status,
          'summary': model.summary,
          'error_message': model.errorMessage,
        })
        .eq('id', model.id)
        .select()
        .single();

    return DocumentModel.fromJson(response);
  }
}