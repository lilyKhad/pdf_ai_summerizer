import 'package:flutter_riverpod/legacy.dart';
import 'package:pdf_summerizer/core/injection/injection.dart';
import 'package:pdf_summerizer/features/auth/domain/entity/user_entity.dart';
import 'package:pdf_summerizer/features/auth/domain/repo/user_repo.dart';

// ─────────────────────────────────────────
// STATE
// ─────────────────────────────────────────

class AuthState {
  final UserEntity? user;
  final bool isLoading;
  final String? errorMessage;

  const AuthState({
    this.user,
    this.isLoading = false,
    this.errorMessage,
  });

  bool get isAuthenticated => user != null;

  AuthState copyWith({
    UserEntity? user,
    bool? isLoading,
    String? errorMessage,
  }) {
    return AuthState(
      user: user ?? this.user,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }
}

// ─────────────────────────────────────────
// NOTIFIER
// ─────────────────────────────────────────

class AuthNotifier extends StateNotifier<AuthState> {
  final UserRepository _repository;

  AuthNotifier(this._repository) : super(const AuthState()) {
    _init(); // check session on app start
  }

  // called once on startup
  Future<void> _init() async {
    state = state.copyWith(isLoading: true);
    final user = await _repository.getCurrentUser();
    state = state.copyWith(user: user, isLoading: false);

    // listen to Supabase auth changes (logout, session expiry)
    _repository.authStateChanges().listen((user) {
      state = state.copyWith(user: user, errorMessage: null);
    });
  }

  Future<void> signIn(String email, String password) async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      final user = await _repository.signIn(email, password);
      state = state.copyWith(user: user, isLoading: false);
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: _parseError(e),
      );
    }
  }

  Future<void> signUp(String email, String password) async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      final user = await _repository.signUp(email, password);
      state = state.copyWith(user: user, isLoading: false);
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: _parseError(e),
      );
    }
  }

  Future<void> signOut() async {
    state = state.copyWith(isLoading: true);
    try {
      await _repository.signOut();
      state = const AuthState(); // reset to empty state
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: _parseError(e),
      );
    }
  }

  void clearError() {
    state = state.copyWith(errorMessage: null);
  }

  String _parseError(Object e) {
    final message = e.toString();
    if (message.contains('Invalid login credentials')) {
      return 'Wrong email or password';
    } else if (message.contains('User already registered')) {
      return 'An account with this email already exists';
    } else if (message.contains('network')) {
      return 'No internet connection';
    }
    return 'Something went wrong, please try again';
  }
}

// ─────────────────────────────────────────
// PROVIDER
// ─────────────────────────────────────────

final authProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  return AuthNotifier(ref.read(userRepositoryProvider));
});