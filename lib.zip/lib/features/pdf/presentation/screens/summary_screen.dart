import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:pdf_summerizer/features/pdf/presentation/providers/document_provider.dart';

class SummaryScreen extends ConsumerWidget {
  final String documentId;

  const SummaryScreen({super.key, required this.documentId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final doc = ref.watch(documentByIdProvider(documentId));

    if (doc == null) {
      return const Scaffold(
        body: Center(child: Text('Document not found')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(doc.name, overflow: TextOverflow.ellipsis),
        actions: [
          // copy summary to clipboard
          if (doc.hasSummary)
            IconButton(
              icon: const Icon(Icons.copy),
              tooltip: 'Copy summary',
              onPressed: () {
                Clipboard.setData(ClipboardData(text: doc.summary!));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Summary copied!')),
                );
              },
            ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: _buildBody(context, ref, doc),
      ),
    );
  }

  Widget _buildBody(BuildContext context, WidgetRef ref, doc) {
    // processing
    if (doc.isProcessing) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Summarizing your document...'),
            SizedBox(height: 8),
            Text(
              'This may take a moment',
              style: TextStyle(color: Colors.grey, fontSize: 12),
            ),
          ],
        ),
      );
    }

    // error
    if (doc.hasError) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 64, color: Colors.red),
            const SizedBox(height: 16),
            const Text('Summarization failed'),
            const SizedBox(height: 8),
            Text(
              doc.errorMessage ?? 'Unknown error',
              style: const TextStyle(color: Colors.grey, fontSize: 12),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () => ref
                  .read(documentProvider.notifier)
                  .summarizeDocument(doc.id),
              icon: const Icon(Icons.refresh),
              label: const Text('Try Again'),
            ),
          ],
        ),
      );
    }

    // summary
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // doc info
          Row(
            children: [
              const Icon(Icons.picture_as_pdf_outlined, color: Colors.grey),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  doc.name,
                  style: const TextStyle(color: Colors.grey),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Text(
                '${doc.size.toStringAsFixed(2)} MB',
                style: const TextStyle(color: Colors.grey, fontSize: 12),
              ),
            ],
          ),
          const Divider(height: 32),

          // summary title
          const Text(
            'Summary',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),

          // summary text
          Text(
            doc.summary ?? '',
            style: const TextStyle(fontSize: 16, height: 1.6),
          ),
        ],
      ),
    );
  }
}