import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:pdf_summerizer/features/auth/presentation/providers/auth_provider.dart';
import 'package:pdf_summerizer/features/pdf/domain/entity/pdf_document.dart';
import 'package:pdf_summerizer/features/pdf/presentation/providers/document_provider.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(documentProvider);
    final auth = ref.watch(authProvider);
    
    //  load documents once when home screen opens
    ref.listen<AuthState>(authProvider, (prev, next) {
      if (next.isAuthenticated && prev?.isAuthenticated != true) {
        ref.read(documentProvider.notifier).loadDocuments();
      }
    });

    // trigger initial load
    if (state.documents.isEmpty && !state.isLoading) {
      Future.microtask(() =>
          ref.read(documentProvider.notifier).loadDocuments());
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Documents'),
        actions: [
          // user email
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: Center(
              child: Text(
                auth.user?.email ?? '',
                style: const TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ),
          ),
          // logout
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => ref.read(authProvider.notifier).signOut(),
          ),
        ],
      ),
      body: _buildBody(context, ref, state),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _pickAndUpload(context, ref),
        icon: const Icon(Icons.upload_file),
        label: const Text('Upload PDF'),
      ),
    );
  }

  Widget _buildBody(
      BuildContext context, WidgetRef ref, DocumentState state) {
    if (state.isLoading && state.documents.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }

    if (state.documents.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.picture_as_pdf_outlined, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text('No documents yet', style: TextStyle(color: Colors.grey)),
            SizedBox(height: 8),
            Text('Upload a PDF to get started',
                style: TextStyle(color: Colors.grey, fontSize: 12)),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () => ref.read(documentProvider.notifier).loadDocuments(),
      child: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: state.documents.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (context, index) {
          final doc = state.documents[index];
          return _DocumentTile(doc: doc);
        },
      ),
    );
  }

  Future<void> _pickAndUpload(BuildContext context, WidgetRef ref) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );

    if (result == null || result.files.single.path == null) return;

    await ref
        .read(documentProvider.notifier)
        .addDocument(result.files.single.path!);
  }
}

class _DocumentTile extends ConsumerWidget {
  final DocumentEntity doc;

  const _DocumentTile({required this.doc});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      child: ListTile(
        leading: _buildLeading(),
        title: Text(doc.name, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text('${doc.size.toStringAsFixed(2)} MB'),
        trailing: _buildTrailing(context, ref),
        onTap: doc.isDone
            ? () => Navigator.pushNamed(context, '/summary',
                arguments: doc.id)
            : null,
      ),
    );
  }

  Widget _buildLeading() {
    if (doc.isProcessing) {
      return const SizedBox(
        width: 24,
        height: 24,
        child: CircularProgressIndicator(strokeWidth: 2),
      );
    }
    return Icon(
      doc.isDone
          ? Icons.check_circle_outline
          : doc.hasError
              ? Icons.error_outline
              : Icons.picture_as_pdf_outlined,
      color: doc.isDone
          ? Colors.green
          : doc.hasError
              ? Colors.red
              : Colors.grey,
    );
  }

  Widget _buildTrailing(BuildContext context, WidgetRef ref) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        // summarize or retry button
        if (!doc.isDone && !doc.isProcessing)
          IconButton(
            icon: Icon(
              doc.hasError ? Icons.refresh : Icons.auto_awesome,
              color: doc.hasError ? Colors.red : Colors.blue,
            ),
            tooltip: doc.hasError ? 'Retry' : 'Summarize',
            onPressed: () => ref
                .read(documentProvider.notifier)
                .summarizeDocument(doc.id),
          ),

        // delete button
        IconButton(
          icon: const Icon(Icons.delete_outline, color: Colors.grey),
          onPressed: () => _confirmDelete(context, ref),
        ),
      ],
    );
  }

  Future<void> _confirmDelete(BuildContext context, WidgetRef ref) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete document'),
        content: Text('Are you sure you want to delete "${doc.name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child:
                const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await ref.read(documentProvider.notifier).deleteDocument(doc.id);
    }
  }
}