import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import 'package:pdf_summerizer/core/injection/injection.dart';
import 'package:pdf_summerizer/features/pdf/domain/entity/pdf_document.dart';
import 'package:pdf_summerizer/features/pdf/domain/repository/document_repo.dart';

// ─────────────────────────────────────────
// STATE
// ─────────────────────────────────────────

class DocumentState {
  final List<DocumentEntity> documents;
  final bool isLoading;
  final String? errorMessage;

  const DocumentState({
    this.documents = const [],
    this.isLoading = false,
    this.errorMessage,
  });

  DocumentState copyWith({
    List<DocumentEntity>? documents,
    bool? isLoading,
    String? errorMessage,
  }) {
    return DocumentState(
      documents: documents ?? this.documents,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }
}

// ─────────────────────────────────────────
// NOTIFIER
// ─────────────────────────────────────────

class DocumentNotifier extends StateNotifier<DocumentState> {
  final DocumentRepository _repository;

  DocumentNotifier(this._repository) : super(const DocumentState());

  Future<void> loadDocuments() async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      final docs = await _repository.getAllDocuments();
      state = state.copyWith(documents: docs, isLoading: false);
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'Failed to load documents',
      );
    }
  }

  Future<void> addDocument(String filePath) async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      final newDoc = await _repository.addDocument(filePath);
      // add to the top of the list
      state = state.copyWith(
        documents: [newDoc, ...state.documents],
        isLoading: false,
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'Failed to upload document',
      );
    }
  }

  Future<void> summarizeDocument(String documentId) async {
    // update just that one doc to processing in the list
    _updateDocumentInList(documentId, (doc) =>
        doc.copyWith(status: DocumentStatus.processing));

    try {
      final updated = await _repository.summarizeDocument(documentId);
      _updateDocumentInList(documentId, (_) => updated);
    } catch (e) {
      _updateDocumentInList(documentId, (doc) =>
          doc.copyWith(
            status: DocumentStatus.error,
            errorMessage: 'Summarization failed',
          ));
    }
  }

  Future<void> deleteDocument(String documentId) async {
    try {
      await _repository.deleteDocument(documentId);
      // remove from list immediately
      state = state.copyWith(
        documents: state.documents
            .where((d) => d.id != documentId)
            .toList(),
      );
    } catch (e) {
      state = state.copyWith(errorMessage: 'Failed to delete document');
    }
  }

  void clearError() {
    state = state.copyWith(errorMessage: null);
  }

  // helper — update one doc inside the list without touching the rest
  void _updateDocumentInList(
    String documentId,
    DocumentEntity Function(DocumentEntity) update,
  ) {
    state = state.copyWith(
      documents: state.documents.map((doc) {
        return doc.id == documentId ? update(doc) : doc;
      }).toList(),
    );
  }
}

// ─────────────────────────────────────────
// PROVIDERS
// ─────────────────────────────────────────

final documentProvider =
    StateNotifierProvider<DocumentNotifier, DocumentState>((ref) {
  return DocumentNotifier(ref.read(documentRepositoryProvider));
});

// handy derived providers for the UI
final documentsListProvider = Provider<List<DocumentEntity>>((ref) {
  return ref.watch(documentProvider).documents;
});

final documentByIdProvider = Provider.family<DocumentEntity?, String>((ref, id) {
  return ref.watch(documentsListProvider)
      .where((d) => d.id == id)
      .firstOrNull;
});