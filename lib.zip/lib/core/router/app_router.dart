import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:pdf_summerizer/features/auth/presentation/providers/auth_provider.dart';
import 'package:pdf_summerizer/features/auth/presentation/screens/login_screen.dart';
import 'package:pdf_summerizer/features/auth/presentation/screens/signup_screen.dart';
import 'package:pdf_summerizer/features/pdf/presentation/screens/home_screen.dart';
import 'package:pdf_summerizer/features/pdf/presentation/screens/summary_screen.dart';

class AppRouter extends ConsumerWidget {
  const AppRouter({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authProvider);

    return MaterialApp(
      title: 'PDF Summarizer',
      theme: ThemeData(
        colorSchemeSeed: Colors.blue,
        useMaterial3: true,
      ),
      // ✅ use home instead of initialRoute
      home: _buildHome(auth),
      routes: {
        '/login': (_) => const LoginScreen(),
        '/signup': (_) => const SignupScreen(),
        '/home': (_) => const HomeScreen(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/summary') {
          final documentId = settings.arguments as String;
          return MaterialPageRoute(
            builder: (_) => SummaryScreen(documentId: documentId),
          );
        }
        return null;
      },
    );
  }

  Widget _buildHome(AuthState auth) {
    // still checking session
    if (auth.isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    // decided
    if (auth.isAuthenticated) {
      return const HomeScreen();
    }

    return const LoginScreen();
  }
}